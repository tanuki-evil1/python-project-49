### Hexlet tests and linter status:
[![Actions Status](https://github.com/tanuki-evil1/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tanuki-evil1/python-project-49/actions)
[![asciicast](https://asciinema.org/a/kMQeKUaciyhwUSJd28J8oXJwH.svg)](https://asciinema.org/a/kMQeKUaciyhwUSJd28J8oXJwH)

#!/usr/bin/env python3
from brain_games.cli import get_user_name
from brain_games.scripts.brain_games import main as welcome_user
from brain_games.games.brain_gcd_game import gcd_game


def main():
    welcome_user()
    name = get_user_name()
    print("Find the greatest common divisor of given numbers.")
    gcd_game(name)


if __name__ == '__main__':
    main()
